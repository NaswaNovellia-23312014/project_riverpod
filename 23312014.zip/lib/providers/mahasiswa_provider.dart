import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_riverpod/legacy.dart';

// Notifier isinya berhubungan dengan void
class MahasiswaNotifier extends StateNotifier<List<DocumentSnapshot>> {
  MahasiswaNotifier() : super([]);

  // Fungsi Menambahkan data mahasiswa dari firebase
  Stream<List<DocumentSnapshot>> streamData() {
    return FirebaseFirestore.instance
        .collection('mahasiswa')
        .snapshots()
        .map((snapshot) => snapshot.docs);
  }

  // Fungsi Menambahkan data dari appnya diambil dari firebase
  Future<void> addMahasiswa(String npm, String nama, String prodi) async {
    try {
      await FirebaseFirestore.instance.collection('mahasiswa').add(
        {'npm': npm, 'nama': nama, 'prodi': prodi},
      ); // diatas ini bagian kiri tulisan npm dll diambil dari field di firebase dan yang sebelah kanan npm dll ini itu adalah sebuah variabel
    } on Exception catch (e) {
      // TODO
      print(
        "error input data mahasiswa: $e",
      ); // cara untuk ini yakni menggunakan refactor dengan blok sampai titik koma klik kanan dan pilih refactor kemudian pilih catch
    }
  }

  // Fungsi Delete Data Mahasiswa
  Future<void> deleteMahasiswa(String id) async {
    try {
      await FirebaseFirestore.instance.collection('mahasiswa').doc(id).delete();
    } on Exception catch (e) {
      // TODO
      print('error delete data mahasiswa : $e');
    }
  }
}

// Provider untuk mengambil data
final MahasiswaProvider =
    StateNotifierProvider<MahasiswaNotifier, List<DocumentSnapshot>>(
      (ref) => MahasiswaNotifier(),
    );
