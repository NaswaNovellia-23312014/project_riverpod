// notifier tempat untuk menyimpan
import 'package:flutter_riverpod/flutter_riverpod.dart';

class HomeNotifier {}

// providernya
final HomeProvider = Provider<HomeNotifier>((ref) => HomeNotifier());
